//
//  ViewController.swift
//  Movielmk
//
//  Created by 소프트웨어컴퓨터 on 2026/04/28.
//

import UIKit


let name = ["살목지","란 12.4" ,"짱구","프로젝트 헤일메리","왕과 사는 남자","내 이름은","리 크로닌의 미이라","기동전사 건담", "건국전쟁", "미션 임파서블 : 데드 레코닝"]
let audience = [2025660, 140927, 179528, 2506504, 16716939, 165682, 30945, 19744, 5180000, 8920000]

struct MovieData : Codable {
    let boxOfficeResult : BoxOfficeResult
}
struct BoxOfficeResult : Codable {
    let dailyBoxOfficeList : [DailyBoxOfficeList]
}
struct DailyBoxOfficeList : Codable {
    let movieNm : String
    let audiCnt : String
    let audiAcc : String
    let rank : String
}
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var table: UITableView!
    var movieData : MovieData?
    var movieURL = "https://kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json?key=39fc2089367669f66483a7492aae9f6a&targetDt="
    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self; table.dataSource = self
        movieURL += makeYesterdayString()
        getData()
    }
    func makeYesterdayString() -> String {
        let y = Calendar.current.date(byAdding:.day,value: -1, to:Date())!
        let dateF = DateFormatter()
        dateF.dateFormat="yyyyMMdd"
        let day = dateF.string(from: y)
        return day
    }
    func getData() {
        guard let url = URL(string: movieURL) else { return } // 1단계 :  내가 접속할 url 주소를 만드는 단계
        let session = URLSession(configuration: .default) // 2단계 : 기본 설정을 사용하는 URLSession 객체 생성
            let task = session.dataTask(with: url) { data, response, error in // url로 네트워크 요청을 보내고 결과를 비동기로 받음
            if error != nil { return } // 에러가 발생하면 함수 종료
            guard let JSONdata = data else { return } // 받아온 데이터가 없으면 종료
            print(JSONdata) // 서버에서 받아온 데이터 출력 , 3689 bytes
            let dataString = String(data:JSONdata,encoding: .utf8)
            //print(dataString!)
            let decoder = JSONDecoder() // JSONDecoder형의 인스턴스 하나 만들었음
                do {
                    let decodedData = try decoder.decode(MovieData.self, from: JSONdata)
                    print(decodedData.boxOfficeResult.dailyBoxOfficeList[2].movieNm) // 영화 제목
                    print(decodedData.boxOfficeResult.dailyBoxOfficeList[2].audiAcc) // 누적 관객수
                    self.movieData = decodedData
                    DispatchQueue.main.async {
                        self.table.reloadData()
                    }
                } catch {
                    print(error)
                }
        }
        task.resume()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10;
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //print(indexPath.description)
    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! MyTableViewCell
//        cell.movieName.text = movieData?.boxOfficeResult.dailyBoxOfficeList[indexPath.row].movieNm
//        cell.audiAccumulate.text=movieData?.boxOfficeResult.dailyBoxOfficeList[indexPath.row].audiAcc
//        cell.audiCount.text=movieData?.boxOfficeResult.dailyBoxOfficeList[indexPath.row].audiCnt
////        cell.movieName.text = "[\(indexPath.row+1)등] \(name[indexPath.row]) : \(audience[indexPath.row])명"
//        
//        // print(indexPath.description,separator: " ",terminator: " ")
//        return cell
//    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! MyTableViewCell
     guard let mRank = movieData?.boxOfficeResult.dailyBoxOfficeList[indexPath.row].rank else {return UITableViewCell()}
     guard let mName = movieData?.boxOfficeResult.dailyBoxOfficeList[indexPath.row].movieNm else {return UITableViewCell()}
     cell.movieName.text = "[\(mRank)위] \(mName)"
     if let aCnt = movieData?.boxOfficeResult.dailyBoxOfficeList[indexPath.row].audiCnt {
      let numF = NumberFormatter()
      numF.numberStyle = .decimal
      let aCount = Int(aCnt)!
      let result = numF.string(for: aCount)!+"명"
      cell.audiCount.text = "어제 : \(result)"
     }
     if let aAcc = movieData?.boxOfficeResult.dailyBoxOfficeList[indexPath.row].audiAcc {
      let numF = NumberFormatter()
      numF.numberStyle = .decimal
      let aAcc1 = Int(aAcc)!
      let result = numF.string(for: aAcc1)!+"명"
      cell.audiAccumulate.text = "누적 : \(result)"
     }
     return cell
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "🍿박스오피스(영화진흥위원회제공:"+makeYesterdayString()+")🍿"
    }
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        return "made by Donald Duck"
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let dest = segue.destination as! DetailViewController
        let myIndexPath = table.indexPathForSelectedRow!
        let row = myIndexPath.row
        dest.movieName  = (movieData?.boxOfficeResult.dailyBoxOfficeList[row].movieNm)!
    }

}


